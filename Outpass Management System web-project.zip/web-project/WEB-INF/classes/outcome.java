import javax.servlet.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import java.util.Date;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javafx.application.Application;
public class outcome extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		PrintWriter out = response.getWriter();
		out.println("<html><head><title> purpose </title><link rel='stylesheet' type='text/css' href='style.css'><style type='text/css'>.links{border-radius:10px;}links:hover{background-color: green;}.per{background-color: hsl(160, 92%, 80%);align-items: center;width:25%;height:50%;}</style></head><body background='background.jpg'style='background-repeat:no-repeat;background-size:cover'><table border='0' width='100%' height='10%'><tr><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='first.html'><font color='white'>ABOUT US</font></a></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='index.html'><font color='white'>LOGIN</font></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='signup1.html'><font color='white'>JOIN US</font></a></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='permission.html'><font color='white'>PERMISSION</font></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='contact.html'><font color='white'>CONTACT</font></td></tr></table><h4 align='center'><font face='impact' size='10' color='blue'>GRANT</font></h4>");
		
		try{

			out.println("<body background='background.jpg'style='background-repeat:no-repeat;background-size:cover'>");
			response.setContentType("text/html");
			Class.forName("com.mysql.jdbc.Driver");
			Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			String total=(String)request.getParameter("total");
			out.println(total);
			Integer count=0;
			Integer tot=Integer.parseInt(total);
			while(count<tot)
			{
				count=count+1;
				String str=Integer.toString(count);
				String rno=request.getParameter(str);
				String result=request.getParameter(rno);
				String desc=request.getParameter(rno+"d");
				String insert="insert into outcome values(?,?,?)";
				PreparedStatement stmt=mycon.prepareStatement(insert);
				stmt.setString(1,rno);
				stmt.setString(2,result);
				stmt.setString(3,desc);
				stmt.executeUpdate();
				out.println(rno);
				out.println(result);
				out.println(desc);
				
			}
		}
		catch(Exception e){
			out.println(e);

		}
		finally{
			out.println("<a href='index.html'>click here</a>");
		}

	}
}