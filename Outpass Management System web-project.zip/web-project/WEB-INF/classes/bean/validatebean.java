package bean;
public class validatebean
{
  String username;
  public validatebean( ) {   }
  public void setUsername(String username)
  {
    this.username = username;
  }
  public String getUsername( )
  {
    return username;
  }
}
