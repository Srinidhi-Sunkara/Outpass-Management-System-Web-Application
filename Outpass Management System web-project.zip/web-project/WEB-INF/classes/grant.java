import javax.servlet.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import java.util.Date;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javafx.application.Application;
public class grant extends HttpServlet
{

	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		PrintWriter out = response.getWriter();
	out.println("<html><head><title> purpose </title><link rel='stylesheet' type='text/css' href='style.css'><style type='text/css'>.links{border-radius:10px;}links:hover{background-color: green;}.per{background-color: hsl(160, 92%, 80%);align-items: center;width:25%;height:50%;}</style></head><body background='background.jpg'style='background-repeat:no-repeat;background-size:cover'><table border='0' width='100%' height='10%'><tr><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='first.html'><font color='white'>ABOUT US</font></a></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='index.html'><font color='white'>LOGIN</font></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='signup1.html'><font color='white'>JOIN US</font></a></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='permission.html'><font color='white'>PERMISSION</font></td><td width='16.6%' align='center' bgcolor='purple' class='links'><a href='contact.html'><font color='white'>CONTACT</font></td></tr></table><h4 align='center'><font face='impact' size='10' color='blue'>GRANT</font></h4>");
		out.println("<body background='background.jpg'style='background-repeat:no-repeat;background-size:cover'>");
		// Date date = Calendar.getInstance().getTime();
		// DateFormat.dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		// String strdate=dateFormat.format(date);
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date now = new Date();
        String strDate = sdf.format(now);
        strDate=strDate.substring(0,10);
        //out.println("Todays Date: "+strDate);
        HttpSession session = request.getSession(true);
		String name=(String)session.getAttribute("name");
		try{
			response.setContentType("text/html");
			Class.forName("com.mysql.jdbc.Driver");
			Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			PreparedStatement stmt=mycon.prepareStatement("select rno,purpose,outtime,intime from permission1");
			out.println("<center><table border='2'>");
			out.println("<h2>"+name+"</h2>");
			out.println("<tr><td>rno</td><td>purpose</td><td>intime</td><td>outtime</td><td>decision</td><td>file download</td></tr>");
			ResultSet rs=stmt.executeQuery();
			int x=0;
			while(rs.next()){
				String rno=rs.getString(1);
				String purpose=rs.getString(2);
				String outtime=rs.getString(3);
				String intime=rs.getString(4);
				outtime=outtime.substring(0,10);
				//out.println(outtime);
				out.println("<form action='outcome' method='POST'>");
				if(outtime.equals(strDate)){
					x=x+1;
				String y=rno+"d";
				String count=Integer.toString(x);
			
			//out.println(x);
			//String count=Integer.toString(x);
			
			
			if(x==0)
			{
				// HttpSession ses=request.getSession(true);
				// ses.setAttribute("rno",rno);
				out.println("No records found for the day");
			}

				out.println("<tr><td>"+rno+"</td><td>"+purpose+"</td><td>"+intime+"</td><td>"+outtime+"</td><td><input type='radio' name="+rno+" value='accept' checked/>accept<input type='radio' name="+rno+" value='ignore'/>ignore<input type=text name="+y+" placeholder='description'/><input type='hidden' name="+count+" value="+rno+"></td><td><a href='DownloadServlet?rno="+rno+"'>Click here</td></tr>");}
			}
			out.println("</table>");
			out.println("<input type='hidden' name='total' value="+x+">");
			//request.setAttribute("total",2);

			out.println("<input type='submit' value='submit'>");
			out.println("</form></center>");
			
			}
		catch(Exception e){
			out.println(e);

		}

	}
}