import javax.servlet.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import javafx.application.Application;
public class intermediate extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		PrintWriter out=response.getWriter();
		try{
			response.setContentType("text/html");
			// Cookie[] cookie=request.getCookies();
			// String rno=cookie[0].getValue();
			String rno=(String)request.getAttribute("rno");
			Class.forName("com.mysql.jdbc.Driver");
			Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			String get="select * from signup where rno='"+rno+"'";
			PreparedStatement stmt1=mycon.prepareStatement(get);
			ResultSet rs=stmt1.executeQuery();
			rs.first();
			String name=rs.getString(1);
			//String password = request.getParameter("password");
			String department=rs.getString(2);
			
			String rlno=rs.getString(3);
			String year=rs.getString(4);
			out.println("successfully inserted");
			request.setAttribute("name",name);
			request.setAttribute("rno",rlno);
			request.setAttribute("department",department);
			request.setAttribute("year",year);
			RequestDispatcher dis=request.getRequestDispatcher("permission");  
			dis.forward(request, response); 
			//out.println("<a href='permission.html'>click here</a>");
			stmt1.close();
			mycon.close();
		}
		catch(Exception e)
		{
			out.println(e);
		}

	}

}