import javax.servlet.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import javafx.application.Application;
public class signupj extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		PrintWriter out=response.getWriter();
		try{
			response.setContentType("text/html");
			String name=request.getParameter("name");
			String password = request.getParameter("password");
			String department=request.getParameter("department");
			String rno=request.getParameter("rollno");
			String year=request.getParameter("year");
			System.out.println(name+" "+password+" "+department+" "+rno+" "+year);
			Class.forName("com.mysql.jdbc.Driver");
			Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			
			String insert="insert into signup values(?,?,?,?,?)";
			PreparedStatement stmt=mycon.prepareStatement(insert);
			stmt.setString(1,name);
			stmt.setString(2,department);
			stmt.setString(3,rno);
			stmt.setString(4,year);
			stmt.setString(5,password);

			stmt.executeUpdate();
			out.println("successfully inserted");
			stmt.close();
			Integer c = 4;
			String insert2="insert into count values(?,?,?)";
			PreparedStatement stmt2=mycon.prepareStatement(insert2);
			stmt2.setString(1,rno);
			stmt2.setInt(2,c);
			stmt2.setInt(3,c);
			stmt2.executeUpdate();
			out.println("successfully inserted");
			stmt2.close();
			mycon.close();
		}
		catch(Exception e)
		{
			out.println(e);
		}

	}

}