import javax.servlet.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import javafx.application.Application;
import java.text.SimpleDateFormat; 
import java.time.*;
import java.util.Date;
public class permission extends HttpServlet{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		PrintWriter out=response.getWriter();
		try{
			response.setContentType("text/html");
			// Cookie[] cookie=request.getCookies();
			// String rno=cookie[0].getValue();
			Class.forName("com.mysql.jdbc.Driver");
			Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			String rno=(String)request.getParameter("rno");
			// String name=(String)request.getAttribute("name");
			// String department=(String)request.getAttribute("department");
			// String rlno=(String)request.getAttribute("rlno");
			// String year=(String)request.getAttribute("year");
			Integer available=Integer.parseInt(request.getParameter("available"));
			String purpose=request.getParameter("purpose");
			String intime=request.getParameter("intime");
			out.println("<br>received intime"+intime);
			String outtime=request.getParameter("outtime");
			String indate=intime.substring(0,10);
			String outdate=outtime.substring(0,10);
			String intt=((intime.substring(11,13)).concat(":")).concat(intime.substring(14,16));//for time
			String outt=((outtime.substring(11,13)).concat(":")).concat(outtime.substring(14,16));
			Integer inh=Integer.parseInt(intime.substring(11,13));//For hours
			Integer outh=Integer.parseInt(outtime.substring(11,13));
			indate=indate.concat(" ");
			outdate=outdate.concat(" ");
			outtime=outdate.concat(outt);
			intime=indate.concat(intt);			
			SimpleDateFormat formatter6=new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
			Date outd=formatter6.parse(outtime);
			SimpleDateFormat formatter5=new SimpleDateFormat("yyyy-MM-dd HH:mm"); 
			Date ind=formatter5.parse(intime);
			out.println("<h3 style='align:center'>Hello '"+rno+"'</h3>");
			out.println("<br>outtime:");
			out.print(outd);
			out.println("<br>inttime:");
			out.print(ind);	
			String dateString=outd.toString();
			String outday=dateString.substring(0,3);
			out.println("Day is :"+outday);
		 	

			if((ind.compareTo(outd)>0)&&(inh<18)){
			String insert="insert into permission1 values(?,?,?,?,?)";
			PreparedStatement stmt=mycon.prepareStatement(insert);
			stmt.setString(1,rno);
			stmt.setInt(2,available);
			stmt.setString(3,purpose);
			stmt.setString(4,intime);
			stmt.setString(5,outtime);

			stmt.executeUpdate();
			out.println("successfully inserted");
			stmt.close();
			String str;
			if((outday.equalsIgnoreCase("Sat"))||(outday.equalsIgnoreCase("Sun"))){
				str="out time is saturday or sunday";
			}
			else{
					str="out time is not a saturday or sunday upload leave letter";

			}
					request.setAttribute("str",str);
					request.setAttribute("rno",rno);
					RequestDispatcher dis=request.getRequestDispatcher("upload.jsp");
					dis.forward(request, response); 
			}
			else{
				out.println("request has not been accepted<br>check intime and outtime");
				out.println("<a href='index.html'>click here to go back</a>");
			}
			
			mycon.close();
		}
		catch(Exception e)
		{
			out.println(e);
			out.println("U have already requested for outpass");
		}

	}

}