import javax.servlet.*;
import java.sql.*;
import java.io.*;
import javax.servlet.http.*;
import javafx.application.Application;
import java.util.*;
public class login extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		PrintWriter out = response.getWriter();
		try{
			response.setContentType("text/html");
			Class.forName("com.mysql.jdbc.Driver");
			Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			String name=request.getParameter("username");
			String password=request.getParameter("password");
			String desg=request.getParameter("designation");
			if(desg.contains("student"))
			{
			PreparedStatement stmt=mycon.prepareStatement("select password,rno,department,year from signup where name=?");
			stmt.setString(1,name);

			ResultSet rs=stmt.executeQuery();
			while(rs.next()){
				String pass=rs.getString(1);
				String rno=rs.getString(2);
				String department=rs.getString(3);
				String year = rs.getString(4);
				
			if(password.equals(pass))
			{
				request.setAttribute("rno",rno);
				
				
				RequestDispatcher dis=request.getRequestDispatcher("permission.jsp");   
          		dis.forward(request, response); 
						
			}
			else
			{
				out.println("<h4 style='align: center;'>not correct</h4>");
				RequestDispatcher dis=request.getRequestDispatcher("index.html");          
          		dis.include(request, response);     
			}
		}
		}
		if(desg.equals("warden")){
			PreparedStatement stmt=mycon.prepareStatement("select password from wsignup where name=?");
			stmt.setString(1,name);

			ResultSet rs=stmt.executeQuery();
			while(rs.next()){
				String pass=rs.getString(1);
			if(password.equals(pass))
			{
				HttpSession session = request.getSession();
				session.setAttribute("name",name);
				RequestDispatcher dis=request.getRequestDispatcher("grant");  
				dis.forward(request, response); 
						
			}
			else
			{
				out.println("<h4 style='align: center;'>not correct</h4>");
				RequestDispatcher dis=request.getRequestDispatcher("index.html");          
          		dis.include(request, response);     
			}
		}
		}
		}
		catch(Exception e){
			out.println(e);

		}

	}
}